<?php
// Heading
$_['heading_title']				= 'Credits';

// Entry
$_['entry_completed']			= 'Completed Status';
$_['entry_status']				= 'Status';
$_['entry_sort_order']			= 'Sort Order';

// Text
$_['text_payments']				= 'Payments';
$_['text_success']				= 'You have successfully modified Credits.';

// Error
$_['error_permission']			= 'You do not have permission to modify Credits.';