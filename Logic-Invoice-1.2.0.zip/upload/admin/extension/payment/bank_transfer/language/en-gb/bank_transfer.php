<?php
// Heading
$_['heading_title']				= 'Bank Transfer';

// Entry
$_['entry_details']				= 'Details';
$_['entry_completed']			= 'Completed Status';
$_['entry_status']				= 'Status';
$_['entry_sort_order']			= 'Sort Order';

// Text
$_['text_payments']				= 'Payments';
$_['text_success']				= 'You have successfully modified Bank Transfer.';

// Error
$_['error_permission']			= 'You do not have permission to modify Bank Transfer.';