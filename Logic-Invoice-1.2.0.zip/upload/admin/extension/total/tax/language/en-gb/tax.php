<?php
// Heading
$_['heading_title']				= 'Tax';

// Entry
$_['entry_status']				= 'Status';
$_['entry_sort_order']			= 'Sort Order';

// Text
$_['text_totals']				= 'Totals';
$_['text_success']				= 'You have successfully modified tax.';

// Error
$_['error_permission']			= 'You do not have permission to modify tax.';