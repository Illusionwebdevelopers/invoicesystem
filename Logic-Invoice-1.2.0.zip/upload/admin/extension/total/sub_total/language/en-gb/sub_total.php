<?php
// Heading
$_['heading_title']				= 'Sub-Total';

// Entry
$_['entry_status']				= 'Status';
$_['entry_sort_order']			= 'Sort Order';

// Text
$_['text_totals']				= 'Totals';
$_['text_success']				= 'You have successfully modified sub-total.';

// Error
$_['error_permission']			= 'You do not have permission to modify sub-total.';