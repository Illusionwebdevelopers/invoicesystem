<?php
// Heading
$_['heading_title']		= 'Totals';

// Column
$_['column_name']		= 'Name';
$_['column_author']		= 'Author';
$_['column_version']	= 'Version';
$_['column_status']		= 'Status';
$_['column_sort_order']	= 'Sort Order';
$_['column_action']		= 'Action';

// Text
$_['text_no_results']	= 'There is no total to list.';
$_['text_success']		= 'You have successfully modified totals.';

// Error
$_['error_permission']	= 'You do not have permission to modify total.';