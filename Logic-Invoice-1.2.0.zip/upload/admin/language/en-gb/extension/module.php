<?php
// Heading
$_['heading_title']		= 'Modules';

// Column
$_['column_name']		= 'Name';
$_['column_author']		= 'Author';
$_['column_version']	= 'Version';
$_['column_action']		= 'Action';

// Text
$_['text_no_results']	= 'There is no module to list.';
$_['text_success']		= 'You have successfully modified modules.';

// Error
$_['error_permission']	= 'You do not have permission to modify modules.';