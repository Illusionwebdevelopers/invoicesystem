<?php
// Heading
$_['heading_title'] 	= 'Forgotten Password';

// Text
$_['text_success']		= 'You have successfully sent reset instructions.';

// Entry
$_['entry_email']		= 'Email';

// Error
$_['error_warning']		= 'The email address you had entered is incorrect!';