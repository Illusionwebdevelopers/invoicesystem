<?php
// Heading
$_['heading_title'] 	= 'Permission Denied';

// Text
$_['text_permission']	= 'You do not have permission to view this page. Please contact your system administrator for more details.';