<?php
// Text
$_['text_powered']		= '<a href="http://www.logicinvoice.com">Logic Invoice</a> &copy; 2014-%s. All rights reserved.';
$_['text_version']		= 'Version %s';