<?php
// Heading
$_['heading_title'] 	= 'Reset Password';

// Text
$_['text_success']		= 'You have successfully reset your password.';

// Entry
$_['entry_password']	= 'Password';
$_['entry_confirm']		= 'Confirm Password';

// Error
$_['error_password']	= 'Password must be between 6 and 25 characters.';
$_['error_confirm']		= 'Passwords do not match.';