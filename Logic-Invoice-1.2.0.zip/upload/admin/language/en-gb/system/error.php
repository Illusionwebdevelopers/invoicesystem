<?php
// Heading
$_['heading_title']		= 'Error Log';

// Text
$_['text_success']		= 'You have successfully cleared your error log.';

// Error
$_['error_permission']	= 'You do not have permission to clear the error log.';