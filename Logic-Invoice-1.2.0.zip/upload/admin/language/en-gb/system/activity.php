<?php
// Heading
$_['heading_title']			= 'Activity Log';

// Column
$_['column_date_added']		= 'Date Added';
$_['column_message']		= 'Message';

// Text
$_['text_no_results']		= 'There is no activity to list.';
$_['text_success']			= 'You have successfully modified activity log.';
$_['text_clear']			= '[Activity Log] Activity log was cleared by %s.';

// Error
$_['error_permission']		= 'You do not have permission to modify activity log.';