<?php
// Heading
$_['heading_title']							= 'Statement of Comprehensive Income';

// Entry
$_['entry_date_start']						= 'Date Start';
$_['entry_date_end']						= 'Date End';

// Text
$_['text_revenue']							= 'Revenue';
$_['text_total_revenue']					= 'Total Revenue';
$_['text_expense']							= 'Expense';
$_['text_total_expense']					= 'Total Expense';
$_['text_net_profit']						= 'Net Profit';