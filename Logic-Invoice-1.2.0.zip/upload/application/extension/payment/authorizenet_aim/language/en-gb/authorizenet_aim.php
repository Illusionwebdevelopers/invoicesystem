<?php
// Heading
$_['heading_title']			= 'Credit Card / Debit Card (Processed by Authorize.Net)';

// Text
$_['text_updated']			= '[Invoice] Invoice #%s status updated to %s by customer.';

// Entry
$_['entry_cc_owner']		= 'Card Owner';
$_['entry_cc_number']		= 'Card Number';
$_['entry_cc_expire_date']	= 'Card Expiry Date';
$_['entry_cc_cvv2']			= 'Card Security Code (CVV2)';