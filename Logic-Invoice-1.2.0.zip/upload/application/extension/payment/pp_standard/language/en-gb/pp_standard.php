<?php
// Heading
$_['heading_title']		= 'PayPal Standard';

// Text
$_['text_sandbox']		= 'Warning: Payment method is in sandbox mode!';
$_['text_updated']		= '[Invoice] Invoice #%s status updated to %s by customer.';