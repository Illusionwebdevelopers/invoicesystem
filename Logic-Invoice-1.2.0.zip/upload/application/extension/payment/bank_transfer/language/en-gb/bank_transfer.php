<?php
// Heading
$_['heading_title']		= 'Bank Transfer';

// Text
$_['text_updated']		= '[Invoice] Invoice #%s status updated to %s by customer.';