<?php
// Heading
$_['heading_title']			= 'Credits';

// Text
$_['text_updated']			= '[Invoice] Invoice #%s status updated to %s by customer.';
$_['text_credit']			= 'You have %s credits available.';
$_['text_invoice']			= 'Payment for invoice #%s';

// Error
$_['error_insufficient']	= 'You do not have sufficient credits to pay this invoice.';