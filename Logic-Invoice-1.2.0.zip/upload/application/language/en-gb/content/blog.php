<?php
// Heading
$_['heading_title'] 	= 'Blog';

// Text
$_['text_read_more']	= 'Read more';
$_['text_no_results']	= 'There is no blog post to list.';
$_['text_by']			= 'By';