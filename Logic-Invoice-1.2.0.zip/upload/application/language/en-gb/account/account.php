<?php
// Heading
$_['heading_title'] 	= 'My Account';

// Text
$_['text_account'] 		= 'My Account';
$_['text_info']			= 'Manage your invoices and recurring bills here.';
$_['text_update']		= 'Update Details';
$_['text_password']		= 'Change Password';
$_['text_invoice']		= 'My Invoices';
$_['text_recurring']	= 'My Recurring Bills';
$_['text_credit']		= 'My Credits';