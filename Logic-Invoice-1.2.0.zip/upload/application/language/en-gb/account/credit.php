<?php
// Heading
$_['heading_title'] 			= 'My Credits';

// Column
$_['column_amount']				= 'Amount';
$_['column_description']		= 'Description';
$_['column_date_added']			= 'Date Added';

// Text
$_['text_account']				= 'My Account';
$_['text_info']					= 'View your credit transactions here.';
$_['text_no_results']			= 'There is no credit to list.';
$_['text_credit']				= 'Total credits: %s';