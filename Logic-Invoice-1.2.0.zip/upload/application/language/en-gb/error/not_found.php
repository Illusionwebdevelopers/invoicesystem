<?php
// Heading
$_['heading_title']		= '404 Page Not Found';

// Text
$_['text_info']			= 'The page you are looking for cannot be found.';
$_['text_not_found']	= 'Yikes! You stumbled upon a page that we do not have! Why not go back to our home page?';