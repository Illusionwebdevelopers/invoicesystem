<?php
// Heading
$_['heading_title']    = 'Under Maintenance';

// Text
$_['text_message']     = 'We are currently performing some scheduled maintenance. We will be back as soon as possible. Please check back soon.';