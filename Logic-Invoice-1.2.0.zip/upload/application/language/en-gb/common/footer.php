<?php
$_['text_powered'] 		= '%s &copy; %s.<br />Powered by <a href="http://www.logicinvoice.com">Logic Invoice</a>.';