<?php
$_['text_home']			= 'Home';
$_['text_blog']			= 'Blog';
$_['text_client'] 		= 'Client Area';
$_['text_account'] 		= 'My Account';
$_['text_invoice'] 		= 'My Invoices';
$_['text_login'] 		= 'Login';
$_['text_logout'] 		= 'Logout';
$_['text_register'] 	= 'Register';