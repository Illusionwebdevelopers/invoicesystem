<?php
// Text
$_['text_login'] 	= '[API Login] %s successfully authenticated.';

// Error
$_['error_login']	= 'API login failed!';