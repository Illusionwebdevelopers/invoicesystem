<?php
// Text
$_['text_added']			= '[Inventory] %s (#%s) added by %s.';
$_['text_edited']			= '[Inventory] %s (#%s) edited by %s.';
$_['text_deleted']			= '[Inventory] #%s deleted by %s.';

// Error
$_['error_sku']				= 'SKU must be between 1 and 255 characters.';
$_['error_name']			= 'Name must be between 3 and 255 characters.';